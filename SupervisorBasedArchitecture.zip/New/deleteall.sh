microk8s kubectl delete deployment auto-scaler 
microk8s kubectl delete svc auto-scaler
microk8s kubectl delete scaledobject php-auto-scaler

